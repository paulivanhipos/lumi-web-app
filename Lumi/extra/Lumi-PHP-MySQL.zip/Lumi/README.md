# Lumi — Bucket List & Diary (PHP + MySQL)

## Paano patakbuhin sa XAMPP

1. **I-install ang XAMPP** → https://www.apachefriends.org
2. **I-copy ang folder** `Lumi` papunta sa:
   - Windows: `C:\xampp\htdocs\lumi`
   - Mac: `/Applications/XAMPP/htdocs/lumi`
3. Buksan ang **XAMPP Control Panel** → i-**Start** ang **Apache** at **MySQL**.
4. Buksan ang **http://localhost/phpmyadmin**
   → tab na **Import** → **Choose File** → piliin ang `database/lumi_db.sql` → **Import / Go**.
   (Gagawa ito ng database na `lumi_db` at 10 tables.)
5. Buksan ang app: **http://localhost/lumi/**
6. Mag-**Sign up**. Sa **Settings** makikita mo ang "☁️ Connected to the Lumi database".

## Mga folder

| Folder / file | Laman |
|---|---|
| `index.html` | Ang app |
| `css/style.css` | Design |
| `js/app.js` | Lahat ng features ng Lumi |
| `js/backend.js` | Kumokonekta sa PHP API (login, save, upload) |
| `api/` | PHP backend (REST API, JSON) |
| `api/config.php` | Settings ng database (host, user, password) |
| `api/state.php` | Nagko-convert ng app data ↔ MySQL tables |
| `database/lumi_db.sql` | Database schema (i-import sa phpMyAdmin) |
| `uploads/` | Dito nase-save ang mga photo at video ng users |

## Database tables (`lumi_db`)

| Table | Laman |
|---|---|
| `users` | Accounts (password naka-hash gamit ang `password_hash`) |
| `dreams` | Bucket list items |
| `journal_entries` | Dream journal |
| `memories` | Memory collection |
| `memory_media` | Mga photo/video sa bawat memory |
| `goals` | Goals |
| `future_letters` | Letters to future self |
| `life_events` | Timeline events |
| `dream_places` | Sariling dream destinations |
| `app_state` | Settings, theme, AI chat, vision boards, wishlist, badges, atbp. |

## API endpoints (`api/`)

| Endpoint | Method | Gamit |
|---|---|---|
| `register.php` | POST | Gumawa ng account |
| `login.php` | POST | Mag-login (session cookie) |
| `logout.php` | POST | Mag-logout |
| `me.php` | GET | Sino ang naka-login + lahat ng data niya |
| `sync.php` | POST | I-save ang data sa database |
| `upload.php` | POST | Mag-upload ng photo/video file |
| `upload_data.php` | POST | Mag-upload ng image (cover, profile, atbp.) |
| `change_password.php` | POST | Palitan ang password |
| `update_profile.php` | POST | Palitan ang pangalan |
| `delete_account.php` | POST | Burahin ang account at lahat ng data |

## Kung may problema

- **"Cannot connect to the database"** → Naka-Start ba ang MySQL? Na-import mo ba ang `lumi_db.sql`?
  May password ba ang MySQL mo? Ilagay sa `api/config.php` (`DB_PASS`).
- **"Offline mode" sa Settings** → Binuksan mo ang file nang direkta (double-click). Dapat sa
  `http://localhost/lumi/` mo ito buksan.
- **Hindi ma-upload ang malaking video** → Sa XAMPP: *Apache → Config → php.ini*, palitan ang
  `upload_max_filesize = 200M` at `post_max_size = 210M`, tapos i-restart ang Apache.
- **Mic ng Lumi Call** → Gumagana sa `http://localhost`. Kung bubuksan sa ibang device gamit ang IP
  (hal. `http://192.168.1.5/lumi`), kailangan ng HTTPS para sa mic.

## Buksan sa cellphone (same Wi-Fi)

1. Alamin ang IP ng computer (`ipconfig` sa Windows, hal. `192.168.1.5`).
2. Sa cellphone: `http://192.168.1.5/lumi/`
3. Kung ayaw bumukas, i-allow ang Apache sa Windows Firewall.
