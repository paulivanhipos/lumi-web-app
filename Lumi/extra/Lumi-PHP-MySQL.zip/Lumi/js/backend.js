/* =============================================================
   Lumi ↔ PHP + MySQL backend (XAMPP)
   - If the PHP server is running, accounts and data are saved
     in the MySQL database (and photos/videos in /uploads).
   - If it is not (e.g. opened as a plain file), Lumi still works
     in "offline mode" and saves on this device only.
   ============================================================= */
"use strict";
const API = { online: false, ready: false, base: 'api/', timer: null, busy: false, again: false, lastName: '', warned: false, lastSent: '' };
const uploadedURL = {};
async function api(path, data) {
  const isForm = data instanceof FormData, post = data !== undefined;
  const r = await fetch(API.base + path, { method: post ? 'POST' : 'GET', credentials: 'same-origin',
    headers: post && !isForm ? { 'Content-Type': 'application/json' } : {}, body: post ? (isForm ? data : JSON.stringify(data)) : undefined });
  let j; try { j = await r.json(); } catch (e) { throw new Error('Server error (' + r.status + ')'); }
  if (!j.ok) throw new Error(j.error || 'Request failed'); return j;
}

/* ---------- load the user's data from the server ---------- */
function applyServerState(user, state) {
  const prev = load();
  S = deepMerge(defaults(), state || {});
  if (prev.user && prev.user.email === user.email) { S.pin = prev.pin; S.bio = prev.bio; }
  S.user = { id: user.id, name: user.name, email: user.email, created: user.created, pass: '' };
  S.loggedIn = true; API.lastName = user.name;
  saveLocal(); try { loadCustomDest(); } catch (e) {}
}

/* ---------- save: local copy + sync to MySQL ---------- */
const saveLocal = save;
save = function () { saveLocal(); if (API.online && API.ready && S.loggedIn && S.user) scheduleSync(); };
function scheduleSync() { clearTimeout(API.timer); API.timer = setTimeout(doSync, 1200); setSyncBadge('saving'); }
async function uploadInlineImages() {
  const found = []; const seen = new WeakSet();
  (function walk(o) { if (!o || typeof o !== 'object' || seen.has(o)) return; seen.add(o);
    for (const k of Object.keys(o)) { const v = o[k]; if (typeof v === 'string' && v.length > 120 && v.startsWith('data:image/')) found.push([o, k, v]); else if (v && typeof v === 'object') walk(v); } })(S);
  const cache = {};
  for (const [o, k, v] of found) {
    try { if (!cache[v]) cache[v] = (await api('upload_data.php', { data: v })).url; o[k] = cache[v]; } catch (e) { /* keep the data URL, try next time */ }
  }
  if (found.length) saveLocal();
}
async function doSync() {
  if (!API.online || !API.ready || !S.loggedIn || !S.user) return;
  if (API.busy) { API.again = true; return; }
  API.busy = true;
  try {
    await uploadInlineImages();
    if (S.user.name && S.user.name !== API.lastName) { await api('update_profile.php', { name: S.user.name }); API.lastName = S.user.name; }
    const st = JSON.parse(JSON.stringify(S)); delete st.pin; delete st.bio; delete st.user; delete st.loggedIn;
    const json = JSON.stringify(st);
    if (json !== API.lastSent) { await api('sync.php', { state: st }); API.lastSent = json; }
    setSyncBadge('saved'); API.warned = false;
  } catch (e) {
    setSyncBadge('error');
    if (/log in/i.test(e.message)) { toast('Your session ended. Please log in again.'); S.loggedIn = false; saveLocal(); showWelcome(); }
    else if (!API.warned) { API.warned = true; toast('⚠️ Could not save to the server: ' + esc(e.message)); }
  } finally { API.busy = false; if (API.again) { API.again = false; scheduleSync(); } }
}
function setSyncBadge(state) { const b = document.getElementById('syncBadge'); if (!b) return;
  b.textContent = state === 'saving' ? '☁️ Saving…' : state === 'saved' ? '☁️ Saved' : '⚠️ Not saved'; b.style.color = state === 'error' ? 'var(--bad)' : ''; }
window.addEventListener('beforeunload', () => { if (API.timer && API.online && S.loggedIn) { try { const st = JSON.parse(JSON.stringify(S)); delete st.pin; delete st.bio; delete st.user; delete st.loggedIn;
  navigator.sendBeacon && navigator.sendBeacon(API.base + 'sync.php', new Blob([JSON.stringify({ state: st })], { type: 'application/json' })); } catch (e) {} } });

/* ---------- sign up / log in with the server ---------- */
const _showAuthB = showAuth;
showAuth = function (mode) {
  _showAuthB(mode); if (!API.online) return;
  const su = mode === 'signup'; const f = $('#authF');
  f.insertAdjacentHTML('beforeend', '<div class="tiny muted center" style="margin-top:10px">☁️ Your account is saved in the Lumi database</div>');
  f.onsubmit = async e => { e.preventDefault();
    const err = m => { $('#aErr').textContent = m; f.classList.remove('shake'); void f.offsetWidth; f.classList.add('shake'); };
    const email = $('#aEmail').value.trim().toLowerCase(), pass = $('#aPass').value; const btn = f.querySelector('button.btn');
    try {
      btn.disabled = true;
      if (su) { const name = $('#aName').value.trim();
        if (!name) return err('Please enter your name.'); if (pass.length < 8) return err('Password must be at least 8 characters.'); if (pass !== $('#aPass2').value) return err("Passwords don't match.");
        const j = await api('register.php', { name, email, password: pass });
        S = defaults(); S.user = { id: j.user.id, name: j.user.name, email: j.user.email, created: j.user.created, pass: '' }; S.loggedIn = true; API.lastName = j.user.name; API.ready = true;
        saveLocal(); doSync(); showLoading(() => { unlocked = true; enterApp(); }, 1200);
      } else {
        const j = await api('login.php', { email, password: pass }); applyServerState(j.user, j.state); API.ready = true; showLoading(() => { unlocked = true; enterApp(); }, 1200);
      }
    } catch (x) { err(x.message); } finally { btn.disabled = false; }
  };
};
logout = function () {
  confirmBox('Log out of Lumi?', async () => {
    clearTimeout(API.timer); if (API.online) { try { await doSync(); } catch (e) {} try { await api('logout.php', {}); } catch (e) {} }
    const pin = S.pin, bio = S.bio, email = S.user && S.user.email;
    if (API.online) { S = defaults(); S.user = email ? { email, name: '' } : null; S.pin = pin; S.bio = bio; }
    S.loggedIn = false; saveLocal(); unlocked = false; sessionSec = 0; page = 'home'; try { speechSynthesis.cancel(); } catch (e) {}
    const f = $('#fab'); if (f) f.remove(); showWelcome();
  }, { ok: 'Log out' });
};
const _changePwB = changePw;
changePw = function () {
  if (!API.online) return _changePwB();
  modal(`<h2>🔑 Change password<span class="sp"></span><button class="iconbtn" onclick="closeModal()">✕</button></h2><input class="f" type="password" id="op" placeholder="Current password"><input class="f" type="password" id="np" style="margin-top:8px" placeholder="New password (8+ characters)"><input class="f" type="password" id="np2" style="margin-top:8px" placeholder="Re-enter new password"><button class="btn block" style="margin-top:12px" id="cpG">Save</button>`);
  $('#cpG').onclick = async () => { const n = $('#np').value; if (n.length < 8) return toast('Use at least 8 characters.'); if (n !== $('#np2').value) return toast("Passwords don't match.");
    try { await api('change_password.php', { current: $('#op').value, new: n }); closeModal(); toast('🔑 Password changed!'); } catch (e) { toast(esc(e.message)); } };
};
const _rsB = render_settings;
render_settings = function () {
  _rsB();
  const first = document.querySelector('#main .card');
  if (first) first.insertAdjacentHTML('beforebegin', `<div class="card" style="display:flex;align-items:center;gap:10px"><span style="font-size:1.6em">${API.online ? '☁️' : '📴'}</span><div style="flex:1"><b class="small">${API.online ? 'Connected to the Lumi database' : 'Offline mode'}</b><div class="tiny muted">${API.online ? 'Your data is saved in MySQL and works on any device you log in to.' : 'The PHP server is not running, so data is saved on this device only.'}</div></div>${API.online ? '<span class="chip" id="syncBadge">☁️ Saved</span>' : ''}</div>`);
  if (!API.online) return;
  const del = [...document.querySelectorAll('#main button')].find(b => b.textContent.trim() === 'Delete' && /Delete ALL data/.test(b.getAttribute('onclick') || ''));
  if (del) { del.removeAttribute('onclick'); del.onclick = () => confirmBox('Delete your account and ALL data from the database? This can\'t be undone.', async () => {
    try { await api('delete_account.php', {}); } catch (e) { return toast(esc(e.message)); }
    try { localStorage.removeItem(KEY); } catch (e) {} S = defaults(); saveLocal(); unlocked = false; const f = $('#fab'); if (f) f.remove(); toast('Account deleted.'); showWelcome();
  }, { danger: true, ok: 'Delete everything' }); }
};

/* ---------- photos & videos: upload the real file to /uploads ---------- */
const _putMediaB = putMedia;
putMedia = async function (id, blob) {
  await _putMediaB(id, blob).catch(() => {});
  if (!API.online || !S.loggedIn) return;
  try { const fd = new FormData(); const ext = (blob.type.split('/')[1] || 'bin').replace('quicktime', 'mov').replace('jpeg', 'jpg');
    fd.append('file', blob, blob.name || ('media.' + ext)); uploadedURL[id] = (await api('upload.php', fd)).url; }
  catch (e) { toast('⚠️ Upload failed: ' + esc(e.message)); }
};
const _mediaURLB = mediaURL;
mediaURL = async function (x) { if (x.url) return x.url; if (uploadedURL[x.id]) return uploadedURL[x.id]; return _mediaURLB(x); };
const _getMediaB = getMedia;
getMedia = async function (id) { try { return await _getMediaB(id); } catch (e) { return null; } };

/* ---------- start the app ---------- */
(async function bootWithServer() {
  applyTheme();
  try { const me = await api('me.php'); API.online = me.server === 'lumi';
    if (API.online) { if (me.user) applyServerState(me.user, me.state); else if (S.loggedIn) { S.loggedIn = false; saveLocal(); } API.ready = true; }
  } catch (e) { API.online = false; }
  showLoading(() => { if (S.user && S.loggedIn) { if (S.pin) showLock(); else enterApp(); } else showWelcome(); }, 1700);
})();
