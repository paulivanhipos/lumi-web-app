<?php
require __DIR__ . '/config.php'; require_post();
$b = body();
$name = trim((string)($b['name'] ?? '')); $email = strtolower(trim((string)($b['email'] ?? ''))); $pass = (string)($b['password'] ?? '');
if ($name === '' || mb_strlen($name) > 100) fail('Please enter your name.');
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) fail('Please enter a valid email.');
if (strlen($pass) < 8) fail('Password must be at least 8 characters.');
$s = db()->prepare('SELECT id FROM users WHERE email=?'); $s->execute([$email]);
if ($s->fetch()) fail('This email already has an account. Please log in.', 409);
db()->prepare('INSERT INTO users (name,email,password_hash,created_at,last_login) VALUES (?,?,?,UTC_TIMESTAMP(),UTC_TIMESTAMP())')
    ->execute([$name, $email, password_hash($pass, PASSWORD_DEFAULT)]);
$id = (int)db()->lastInsertId();
session_regenerate_id(true); $_SESSION['uid'] = $id;
out(['ok' => true, 'user' => public_user(user_row($id))]);
