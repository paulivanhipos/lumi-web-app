<?php
/* Upload a small image sent as a data URL (covers, thumbnails, avatar…). Same image = same file. */
require __DIR__ . '/config.php'; require_post();
$id = uid(); $b = body(); $data = (string)($b['data'] ?? '');
if (!preg_match('#^data:image/(jpeg|jpg|png|gif|webp);base64,(.+)$#s', $data, $m)) fail('Not an image.');
$bin = base64_decode($m[2], true); if ($bin === false || strlen($bin) > 15 * 1024 * 1024) fail('Image is invalid or too big.');
$ext = $m[1] === 'jpeg' ? 'jpg' : $m[1];
[$dir, $url] = user_upload_dir($id);
$name = sha1($bin) . '.' . $ext;
if (!is_file($dir . '/' . $name)) file_put_contents($dir . '/' . $name, $bin);
out(['ok' => true, 'url' => $url . '/' . $name]);
