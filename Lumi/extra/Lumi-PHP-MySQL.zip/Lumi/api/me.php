<?php
/* Who is logged in? Also used by the app to check that the server is running. */
require __DIR__ . '/config.php';
require __DIR__ . '/state.php';
if (empty($_SESSION['uid'])) out(['ok' => true, 'user' => null, 'server' => 'lumi']);
$u = user_row((int)$_SESSION['uid']);
if (!$u) { session_destroy(); out(['ok' => true, 'user' => null, 'server' => 'lumi']); }
out(['ok' => true, 'server' => 'lumi', 'user' => public_user($u), 'state' => load_state((int)$u['id'])]);
