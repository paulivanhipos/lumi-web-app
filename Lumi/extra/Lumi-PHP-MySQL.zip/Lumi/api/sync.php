<?php
/* Save the whole app state of the logged-in user into the database. */
require __DIR__ . '/config.php'; require_post();
require __DIR__ . '/state.php';
$id = uid(); $b = body();
if (!isset($b['state']) || !is_array($b['state'])) fail('No data.');
save_state($id, $b['state']);
out(['ok' => true, 'saved_at' => gmdate('Y-m-d\TH:i:s\Z')]);
