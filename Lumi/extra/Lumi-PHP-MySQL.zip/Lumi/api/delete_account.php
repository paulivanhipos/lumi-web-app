<?php
/* Deletes the account, all of its rows (ON DELETE CASCADE) and uploaded files. */
require __DIR__ . '/config.php'; require_post();
$id = uid();
db()->prepare('DELETE FROM users WHERE id=?')->execute([$id]);
$dir = UPLOAD_DIR . '/u' . $id;
if (is_dir($dir)) { foreach (glob($dir . '/*') ?: [] as $f) @unlink($f); @rmdir($dir); }
$_SESSION = []; session_destroy();
out(['ok' => true]);
