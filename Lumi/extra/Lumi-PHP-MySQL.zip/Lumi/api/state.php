<?php
/* =============================================================
   Converts between the app's data (JSON) and the MySQL tables.
   Main lists are saved in their own tables; everything else
   (settings, chat, vision boards, wishlist…) goes to app_state.
   ============================================================= */
const TABLE_KEYS = ['dreams', 'entries', 'memories', 'goals', 'letters', 'events', 'customDest'];
const LOCAL_ONLY = ['pin', 'bio', 'user', 'loggedIn'];   // stays on the device

function jenc($v): ?string { return $v === null ? null : json_encode($v, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); }
function jdec($v) { return $v === null ? null : json_decode($v, true); }
function arr($a, $k): array { return isset($a[$k]) && is_array($a[$k]) ? $a[$k] : []; }
/* keep any field the tables don't have, so nothing is lost */
function extra(array $row, array $known): ?string { $x = array_diff_key($row, array_flip($known)); return $x ? jenc($x) : null; }
function withx(array $out, $extra): array { $x = jdec($extra); return is_array($x) ? array_merge($x, $out) : $out; }
function id40($v): string { return substr(preg_replace('/[^A-Za-z0-9_\-]/', '', (string)$v), 0, 40) ?: bin2hex(random_bytes(6)); }

function save_state(int $uid, array $s): void {
    $pdo = db(); $pdo->beginTransaction();
    try {
        foreach (['dreams', 'journal_entries', 'memory_media', 'memories', 'goals', 'future_letters', 'life_events', 'dream_places'] as $t)
            $pdo->prepare("DELETE FROM $t WHERE user_id=?")->execute([$uid]);

        $q = $pdo->prepare('INSERT INTO dreams (id,user_id,title,description,notes,category,priority,status,progress,target_date,completed_at,is_favorite,cover_url,budget,location,country,extra,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
        foreach (arr($s, 'dreams') as $d) {
            $q->execute([id40($d['id'] ?? ''), $uid, str($d['title'] ?? 'Untitled', 200), str($d['desc'] ?? ''), str($d['notes'] ?? ''), str($d['cat'] ?? 'personal', 40),
                in_array($d['priority'] ?? '', ['high', 'med', 'low']) ? $d['priority'] : 'med', in_array($d['status'] ?? '', ['not', 'plan', 'prog', 'done']) ? $d['status'] : 'not',
                max(0, min(100, (int)($d['progress'] ?? 0))), d($d['target'] ?? null), dt($d['completedAt'] ?? null), !empty($d['fav']) ? 1 : 0, str($d['cover'] ?? null, 16000000),
                is_numeric($d['budget'] ?? null) ? $d['budget'] : null, str($d['location'] ?? '', 150), str($d['country'] ?? '', 40),
                extra($d, ['id','title','desc','notes','cat','priority','status','progress','target','completedAt','fav','cover','budget','location','country','created','updated']), dt($d['created'] ?? null) ?: gmdate('Y-m-d H:i:s'), dt($d['updated'] ?? null)]);
        }
        $q = $pdo->prepare('INSERT INTO journal_entries (id,user_id,entry_at,mood,text,dream_id,quote,shared,photos,places,edited_at,extra) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)');
        foreach (arr($s, 'entries') as $e) {
            $photos = $e['photos'] ?? (!empty($e['photo']) ? [$e['photo']] : []);
            $q->execute([id40($e['id'] ?? ''), $uid, dt($e['date'] ?? null) ?: gmdate('Y-m-d H:i:s'), str($e['mood'] ?? 'okay', 20), str($e['text'] ?? ''), str($e['dreamId'] ?? null, 40) ?: null,
                str($e['quote'] ?? '', 300), !empty($e['shared']) ? 1 : 0, jenc($photos), jenc($e['places'] ?? []), dt($e['edited'] ?? null), extra($e, ['id','date','mood','text','dreamId','quote','shared','photo','photos','places','edited'])]);
        }
        $qm = $pdo->prepare('INSERT INTO memories (id,user_id,title,story,date_done,location,dream_id,img_url,before_url,img_from_media,saved_at,extra) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)');
        $qx = $pdo->prepare('INSERT INTO memory_media (id,user_id,memory_id,type,url,thumb_url,file_name,duration,sort_order,extra) VALUES (?,?,?,?,?,?,?,?,?,?)');
        foreach (arr($s, 'memories') as $m) {
            $mid = id40($m['id'] ?? '');
            $qm->execute([$mid, $uid, str($m['cap'] ?? '', 200), str($m['story'] ?? ''), d($m['date'] ?? null), str($m['location'] ?? '', 150), str($m['dreamId'] ?? null, 40) ?: null,
                str($m['img'] ?? null, 16000000), str($m['before'] ?? null, 16000000), !empty($m['imgFromMedia']) ? 1 : 0, dt($m['savedAt'] ?? null), extra($m, ['id','cap','story','date','location','dreamId','img','before','imgFromMedia','savedAt','media'])]);
            foreach (arr($m, 'media') as $i => $x) {
                $qx->execute([id40($x['id'] ?? ''), $uid, $mid, ($x['type'] ?? '') === 'video' ? 'video' : 'image', str($x['url'] ?? null, 16000000), str($x['thumb'] ?? null, 16000000), str($x['name'] ?? '', 200),
                    is_numeric($x['dur'] ?? null) ? $x['dur'] : null, $i, extra($x, ['id','type','url','thumb','name','dur'])]);
            }
        }
        $q = $pdo->prepare('INSERT INTO goals (id,user_id,text,is_done,created_at,extra) VALUES (?,?,?,?,?,?)');
        foreach (arr($s, 'goals') as $g) $q->execute([id40($g['id'] ?? ''), $uid, str($g['t'] ?? '', 255), !empty($g['done']) ? 1 : 0, dt($g['c'] ?? null) ?: gmdate('Y-m-d H:i:s'), extra($g, ['id','t','done','c'])]);
        $q = $pdo->prepare('INSERT INTO future_letters (id,user_id,title,body,unlock_at,created_at,mood,reply,extra) VALUES (?,?,?,?,?,?,?,?,?)');
        foreach (arr($s, 'letters') as $l) $q->execute([id40($l['id'] ?? ''), $uid, str($l['title'] ?? '', 200), str($l['body'] ?? ''), dt($l['unlock'] ?? null) ?: gmdate('Y-m-d H:i:s'), dt($l['created'] ?? null) ?: gmdate('Y-m-d H:i:s'), str($l['mood'] ?? null, 20), str($l['reply'] ?? null), extra($l, ['id','title','body','unlock','created','mood','reply'])]);
        $q = $pdo->prepare('INSERT INTO life_events (id,user_id,title,event_date,category,note,extra) VALUES (?,?,?,?,?,?,?)');
        foreach (arr($s, 'events') as $v) $q->execute([id40($v['id'] ?? ''), $uid, str($v['t'] ?? '', 200), d($v['date'] ?? null) ?: gmdate('Y-m-d'), str($v['cat'] ?? '', 10), str($v['note'] ?? ''), extra($v, ['id','t','date','cat','note'])]);
        $q = $pdo->prepare('INSERT INTO dream_places (id,user_id,name,city,flag_code,photo_url,description,best_time,extra) VALUES (?,?,?,?,?,?,?,?,?)');
        foreach (arr($s, 'customDest') as $p) $q->execute([id40($p['k'] ?? ''), $uid, str($p['n'] ?? 'Place', 120), str($p['cap'] ?? '', 120), str($p['flag'] ?? '', 5), str($p['photo'] ?? null, 16000000), str($p['d'] ?? ''), str($p['best'] ?? '', 60), extra($p, ['k','n','cap','flag','photo','d','best'])]);

        $rest = $s; foreach (array_merge(TABLE_KEYS, LOCAL_ONLY) as $k) unset($rest[$k]);
        $pdo->prepare('INSERT INTO app_state (user_id,data,updated_at) VALUES (?,?,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE data=VALUES(data), updated_at=VALUES(updated_at)')->execute([$uid, jenc($rest)]);
        if (!empty($s['profile']['photo']) && strlen($s['profile']['photo']) < 255) $pdo->prepare('UPDATE users SET avatar_url=? WHERE id=?')->execute([$s['profile']['photo'], $uid]);
        $pdo->commit();
    } catch (Throwable $e) { $pdo->rollBack(); fail('Could not save: ' . $e->getMessage(), 500); }
}

function load_state(int $uid): array {
    $pdo = db(); $q = fn($sql) => (function () use ($pdo, $sql, $uid) { $s = $pdo->prepare($sql); $s->execute([$uid]); return $s->fetchAll(); })();
    $st = $pdo->prepare('SELECT data FROM app_state WHERE user_id=?'); $st->execute([$uid]); $s = jdec($st->fetchColumn() ?: '{}') ?: [];

    $s['dreams'] = array_map(function ($r) { $x = jdec($r['extra']) ?: []; return withx([
        'id' => $r['id'], 'title' => $r['title'], 'desc' => $r['description'] ?? '', 'notes' => $r['notes'] ?? '', 'cat' => $r['category'], 'priority' => $r['priority'], 'status' => $r['status'],
        'progress' => (int)$r['progress'], 'target' => $r['target_date'] ?? '', 'completedAt' => iso($r['completed_at']), 'fav' => (bool)$r['is_favorite'], 'cover' => $r['cover_url'],
        'budget' => $r['budget'] === null ? '' : rtrim(rtrim($r['budget'], '0'), '.'), 'location' => $r['location'] ?? '', 'country' => $r['country'] ?? '',
        'refs' => $x['refs'] ?? [], 'collections' => $x['collections'] ?? [], 'askedOn' => $x['askedOn'] ?? null, 'created' => iso($r['created_at']), 'updated' => iso($r['updated_at']) ?: iso($r['created_at'])], $r['extra']); },
        $q('SELECT * FROM dreams WHERE user_id=? ORDER BY created_at'));
    $s['entries'] = array_map(function ($r) { $ph = jdec($r['photos']) ?: []; return withx([
        'id' => $r['id'], 'date' => iso($r['entry_at']), 'mood' => $r['mood'], 'text' => $r['text'] ?? '', 'photo' => $ph[0] ?? null, 'photos' => $ph, 'places' => jdec($r['places']) ?: [],
        'shared' => (bool)$r['shared'], 'dreamId' => $r['dream_id'] ?? '', 'quote' => $r['quote'] ?? '', 'edited' => iso($r['edited_at'])], $r['extra']); },
        $q('SELECT * FROM journal_entries WHERE user_id=? ORDER BY entry_at'));
    $media = []; foreach ($q('SELECT * FROM memory_media WHERE user_id=? ORDER BY sort_order') as $r)
        $media[$r['memory_id']][] = withx(['id' => $r['id'], 'type' => $r['type'], 'url' => $r['url'], 'thumb' => $r['thumb_url'], 'name' => $r['file_name'], 'dur' => $r['duration'] === null ? null : (float)$r['duration']], $r['extra']);
    $s['memories'] = array_map(fn($r) => withx([
        'id' => $r['id'], 'cap' => $r['title'] ?? '', 'story' => $r['story'] ?? '', 'date' => $r['date_done'], 'location' => $r['location'] ?? '', 'dreamId' => $r['dream_id'] ?? '',
        'img' => $r['img_url'], 'before' => $r['before_url'], 'imgFromMedia' => (bool)$r['img_from_media'], 'savedAt' => iso($r['saved_at']), 'media' => $media[$r['id']] ?? []], $r['extra']),
        $q('SELECT * FROM memories WHERE user_id=? ORDER BY saved_at'));
    $s['goals'] = array_map(fn($r) => withx(['id' => $r['id'], 't' => $r['text'], 'done' => (bool)$r['is_done'], 'c' => iso($r['created_at'])], $r['extra']), $q('SELECT * FROM goals WHERE user_id=? ORDER BY created_at DESC'));
    $s['letters'] = array_map(fn($r) => withx(['id' => $r['id'], 'title' => $r['title'] ?? '', 'body' => $r['body'], 'unlock' => iso($r['unlock_at']), 'created' => iso($r['created_at']), 'mood' => $r['mood'], 'reply' => $r['reply']], $r['extra']), $q('SELECT * FROM future_letters WHERE user_id=? ORDER BY created_at'));
    $s['events'] = array_map(fn($r) => withx(['id' => $r['id'], 't' => $r['title'], 'date' => $r['event_date'], 'cat' => $r['category'], 'note' => $r['note'] ?? ''], $r['extra']), $q('SELECT * FROM life_events WHERE user_id=? ORDER BY event_date'));
    $s['customDest'] = array_map(fn($r) => withx(['k' => $r['id'], 'n' => $r['name'], 'cap' => $r['city'] ?? '', 'flag' => $r['flag_code'] ?? 'ph', 'photo' => $r['photo_url'], 'd' => $r['description'] ?? '', 'best' => $r['best_time'] ?? ''], $r['extra']), $q('SELECT * FROM dream_places WHERE user_id=?'));
    return $s;
}
