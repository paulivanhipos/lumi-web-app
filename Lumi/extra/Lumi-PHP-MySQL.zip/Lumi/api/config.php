<?php
/* =============================================================
   Lumi API — configuration
   Change these if your MySQL user/password are different.
   XAMPP default: user "root", no password.
   ============================================================= */
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'lumi_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('UPLOAD_DIR', __DIR__ . '/../uploads');   // where photos & videos are saved
define('UPLOAD_URL', 'uploads');                   // URL path used by the app
define('MAX_UPLOAD_MB', 200);

ini_set('display_errors', '0');
error_reporting(E_ALL);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
session_set_cookie_params(['lifetime' => 60 * 60 * 24 * 30, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax']);
session_start();

function db(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    try {
        $pdo = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    } catch (Throwable $e) {
        out(['ok' => false, 'error' => 'Cannot connect to the database. Is MySQL running in XAMPP, and did you import database/lumi_db.sql?'], 500);
    }
    return $pdo;
}
function out(array $data, int $code = 200): void { http_response_code($code); echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); exit; }
function fail(string $msg, int $code = 400): void { out(['ok' => false, 'error' => $msg], $code); }
function body(): array { $j = json_decode(file_get_contents('php://input') ?: '[]', true); return is_array($j) ? $j : []; }
function require_post(): void { if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('POST only', 405); }
function uid(): int { if (empty($_SESSION['uid'])) fail('Please log in.', 401); return (int)$_SESSION['uid']; }
function user_row(int $id): ?array { $s = db()->prepare('SELECT id,name,email,avatar_url,created_at FROM users WHERE id=?'); $s->execute([$id]); $u = $s->fetch(); return $u ?: null; }
function public_user(array $u): array { return ['id' => (int)$u['id'], 'name' => $u['name'], 'email' => $u['email'], 'created' => iso($u['created_at'])]; }
/* ISO <-> MySQL date helpers (all times stored in UTC) */
function dt($iso): ?string { if (!$iso) return null; $t = strtotime((string)$iso); return $t ? gmdate('Y-m-d H:i:s', $t) : null; }
function d($s): ?string { if (!$s) return null; $t = strtotime((string)$s); return $t ? gmdate('Y-m-d', $t) : null; }
function iso($mysql): ?string { if (!$mysql) return null; $t = strtotime($mysql . ' UTC'); return $t ? gmdate('Y-m-d\TH:i:s.000\Z', $t) : null; }
function str($v, int $max = 65000): ?string { if ($v === null) return null; $v = (string)$v; return mb_substr($v, 0, $max); }
function user_upload_dir(int $uid): array {
    $dir = UPLOAD_DIR . '/u' . $uid; if (!is_dir($dir)) mkdir($dir, 0775, true);
    return [$dir, UPLOAD_URL . '/u' . $uid];
}
