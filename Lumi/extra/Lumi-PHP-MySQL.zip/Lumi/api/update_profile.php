<?php
require __DIR__ . '/config.php'; require_post();
$id = uid(); $b = body(); $name = trim((string)($b['name'] ?? ''));
if ($name === '') fail('Please enter your name.');
db()->prepare('UPDATE users SET name=? WHERE id=?')->execute([mb_substr($name, 0, 100), $id]);
out(['ok' => true, 'user' => public_user(user_row($id))]);
