<?php
require __DIR__ . '/config.php'; require_post();
require __DIR__ . '/state.php';
$b = body(); $email = strtolower(trim((string)($b['email'] ?? ''))); $pass = (string)($b['password'] ?? '');
$s = db()->prepare('SELECT * FROM users WHERE email=?'); $s->execute([$email]); $u = $s->fetch();
if (!$u || !password_verify($pass, $u['password_hash'])) fail('Incorrect email or password.', 401);
session_regenerate_id(true); $_SESSION['uid'] = (int)$u['id'];
db()->prepare('UPDATE users SET last_login=UTC_TIMESTAMP() WHERE id=?')->execute([$u['id']]);
out(['ok' => true, 'user' => public_user($u), 'state' => load_state((int)$u['id'])]);
