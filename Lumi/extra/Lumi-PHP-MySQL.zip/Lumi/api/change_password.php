<?php
require __DIR__ . '/config.php'; require_post();
$id = uid(); $b = body();
$s = db()->prepare('SELECT password_hash FROM users WHERE id=?'); $s->execute([$id]); $h = $s->fetchColumn();
if (!$h || !password_verify((string)($b['current'] ?? ''), $h)) fail('Current password is incorrect.', 401);
$n = (string)($b['new'] ?? ''); if (strlen($n) < 8) fail('Use at least 8 characters.');
db()->prepare('UPDATE users SET password_hash=? WHERE id=?')->execute([password_hash($n, PASSWORD_DEFAULT), $id]);
out(['ok' => true]);
