<?php
/* Upload a photo or video file (multipart/form-data, field "file"). Returns its URL. */
require __DIR__ . '/config.php'; require_post();
$id = uid();
if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    $err = $_FILES['file']['error'] ?? -1;
    fail($err === UPLOAD_ERR_INI_SIZE || $err === UPLOAD_ERR_FORM_SIZE ? 'File is too big. Increase upload_max_filesize and post_max_size in php.ini.' : 'Upload failed.');
}
$f = $_FILES['file'];
if ($f['size'] > MAX_UPLOAD_MB * 1024 * 1024) fail('File is too big (max ' . MAX_UPLOAD_MB . ' MB).');
$mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']) ?: '';
$allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif', 'image/webp' => 'webp', 'video/mp4' => 'mp4', 'video/webm' => 'webm', 'video/quicktime' => 'mov', 'video/x-m4v' => 'm4v', 'video/3gpp' => '3gp'];
if (!isset($allowed[$mime])) fail('Only photos and videos are allowed.');
[$dir, $url] = user_upload_dir($id);
$name = bin2hex(random_bytes(12)) . '.' . $allowed[$mime];
if (!move_uploaded_file($f['tmp_name'], $dir . '/' . $name)) fail('Could not save the file.', 500);
out(['ok' => true, 'url' => $url . '/' . $name, 'type' => str_starts_with($mime, 'video/') ? 'video' : 'image']);
