-- =============================================================
--  Lumi — Bucket List & Dream Journal
--  MySQL / MariaDB database (for XAMPP)
--  Import this file in phpMyAdmin:  Import → Choose file → Go
-- =============================================================
CREATE DATABASE IF NOT EXISTS lumi_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE lumi_db;

-- 1. Users (accounts)
CREATE TABLE IF NOT EXISTS users (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(100)  NOT NULL,
  email         VARCHAR(190)  NOT NULL UNIQUE,
  password_hash VARCHAR(255)  NOT NULL,
  avatar_url    VARCHAR(255)  NULL,
  created_at    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_login    DATETIME      NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Bucket list dreams
CREATE TABLE IF NOT EXISTS dreams (
  id            VARCHAR(40)   NOT NULL,
  user_id       INT UNSIGNED  NOT NULL,
  title         VARCHAR(200)  NOT NULL,
  description   TEXT          NULL,
  notes         TEXT          NULL,
  category      VARCHAR(40)   NOT NULL DEFAULT 'personal',
  priority      ENUM('high','med','low') NOT NULL DEFAULT 'med',
  status        ENUM('not','plan','prog','done') NOT NULL DEFAULT 'not',
  progress      TINYINT UNSIGNED NOT NULL DEFAULT 0,
  target_date   DATE          NULL,
  completed_at  DATETIME      NULL,
  is_favorite   TINYINT(1)    NOT NULL DEFAULT 0,
  cover_url MEDIUMTEXT   NULL,
  budget        DECIMAL(12,2) NULL,
  location      VARCHAR(150)  NULL,
  country       VARCHAR(40)   NULL,
  extra         JSON          NULL,  -- any other fields
  created_at    DATETIME      NOT NULL,
  updated_at    DATETIME      NULL,
  PRIMARY KEY (user_id, id),
  CONSTRAINT fk_dreams_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Dream journal entries
CREATE TABLE IF NOT EXISTS journal_entries (
  id            VARCHAR(40)   NOT NULL,
  user_id       INT UNSIGNED  NOT NULL,
  entry_at      DATETIME      NOT NULL,
  mood          VARCHAR(20)   NOT NULL,
  text          TEXT          NULL,
  dream_id      VARCHAR(40)   NULL,
  quote         VARCHAR(300)  NULL,
  shared        TINYINT(1)    NOT NULL DEFAULT 0,
  photos        JSON          NULL,
  places        JSON          NULL,
  edited_at     DATETIME      NULL,
  extra         JSON         NULL,
  PRIMARY KEY (user_id, id),
  CONSTRAINT fk_journal_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Memory collection
CREATE TABLE IF NOT EXISTS memories (
  id             VARCHAR(40)  NOT NULL,
  user_id        INT UNSIGNED NOT NULL,
  title          VARCHAR(200) NULL,
  story          TEXT         NULL,
  date_done      DATE         NULL,
  location       VARCHAR(150) NULL,
  dream_id       VARCHAR(40)  NULL,
  img_url MEDIUMTEXT   NULL,
  before_url MEDIUMTEXT   NULL,
  img_from_media TINYINT(1)   NOT NULL DEFAULT 0,
  saved_at       DATETIME     NULL,
  extra         JSON         NULL,
  PRIMARY KEY (user_id, id),
  CONSTRAINT fk_memories_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Photos & videos inside a memory
CREATE TABLE IF NOT EXISTS memory_media (
  id          VARCHAR(40)  NOT NULL,
  user_id     INT UNSIGNED NOT NULL,
  memory_id   VARCHAR(40)  NOT NULL,
  type        ENUM('image','video') NOT NULL,
  url         MEDIUMTEXT   NULL,
  thumb_url MEDIUMTEXT   NULL,
  file_name   VARCHAR(200) NULL,
  duration    DECIMAL(10,2) NULL,
  sort_order  INT          NOT NULL DEFAULT 0,
  extra         JSON         NULL,
  PRIMARY KEY (user_id, id),
  KEY idx_media_memory (user_id, memory_id),
  CONSTRAINT fk_media_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Goals
CREATE TABLE IF NOT EXISTS goals (
  id          VARCHAR(40)  NOT NULL,
  user_id     INT UNSIGNED NOT NULL,
  text        VARCHAR(255) NOT NULL,
  is_done     TINYINT(1)   NOT NULL DEFAULT 0,
  created_at  DATETIME     NOT NULL,
  extra       JSON         NULL,
  PRIMARY KEY (user_id, id),
  CONSTRAINT fk_goals_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Letters to future self
CREATE TABLE IF NOT EXISTS future_letters (
  id          VARCHAR(40)  NOT NULL,
  user_id     INT UNSIGNED NOT NULL,
  title       VARCHAR(200) NULL,
  body        TEXT         NOT NULL,
  unlock_at   DATETIME     NOT NULL,
  created_at  DATETIME     NOT NULL,
  mood        VARCHAR(20)  NULL,
  reply       TEXT         NULL,
  extra         JSON         NULL,
  PRIMARY KEY (user_id, id),
  CONSTRAINT fk_letters_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. Life events / milestones
CREATE TABLE IF NOT EXISTS life_events (
  id          VARCHAR(40)  NOT NULL,
  user_id     INT UNSIGNED NOT NULL,
  title       VARCHAR(200) NOT NULL,
  event_date  DATE         NOT NULL,
  category    VARCHAR(10)  NULL,
  note        TEXT         NULL,
  extra         JSON         NULL,
  PRIMARY KEY (user_id, id),
  CONSTRAINT fk_events_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. User's own dream places
CREATE TABLE IF NOT EXISTS dream_places (
  id          VARCHAR(40)  NOT NULL,
  user_id     INT UNSIGNED NOT NULL,
  name        VARCHAR(120) NOT NULL,
  city        VARCHAR(120) NULL,
  flag_code   VARCHAR(5)   NULL,
  photo_url MEDIUMTEXT   NULL,
  description TEXT         NULL,
  best_time   VARCHAR(60)  NULL,
  extra         JSON         NULL,
  PRIMARY KEY (user_id, id),
  CONSTRAINT fk_places_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. Everything else (settings, themes, AI chat, vision boards, wishlist, badges…)
CREATE TABLE IF NOT EXISTS app_state (
  user_id     INT UNSIGNED NOT NULL PRIMARY KEY,
  data        LONGTEXT     NOT NULL,
  updated_at  DATETIME     NOT NULL,
  CONSTRAINT fk_state_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
